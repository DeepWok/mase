from .base import VisionModelWrapper
