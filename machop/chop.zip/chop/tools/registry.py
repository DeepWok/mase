from pathlib import Path

MACHOP_DIR = Path(__file__).resolve().parents[2]
MACHOP_CACHE_DIR = MACHOP_DIR / ".machop_cache"
