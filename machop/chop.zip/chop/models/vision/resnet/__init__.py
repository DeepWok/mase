from .resnet import (
    get_resnet18,
    get_resnet34,
    get_resnet50,
    get_resnet101,
    get_wide_resnet50_2,
)
