from .wideresnet import wideresnet28_cifar
