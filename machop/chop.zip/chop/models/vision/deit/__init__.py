from .deit import (
    get_deit_base_distilled_patch16_224,
    get_deit_base_distilled_patch16_384,
    get_deit_base_patch16_224,
    get_deit_base_patch16_384,
    get_deit_small_distilled_patch16_224,
    get_deit_small_patch16_224,
    get_deit_tiny_distilled_patch16_224,
    get_deit_tiny_patch16_224,
)

# from .deit_v2 import (

# )
