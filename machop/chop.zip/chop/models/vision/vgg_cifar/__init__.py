from .vgg_cifar import get_vgg7
