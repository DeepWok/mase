This directory contains a few `nn.Module` actions:
* search: TODO
* test: TODO
* train: TODO
* validate: TODO

TODO: Move chop somewhere else and keeps machop as a library