PYTORCH-QUANTIZATION
====================

**WARNING:** This project is not functional and is a placeholder from NVIDIA.
To install, please execute the following:

.. code-block:: bash

    pip install --no-cache-dir --extra-index-url https://pypi.nvidia.com pytorch-quantization
